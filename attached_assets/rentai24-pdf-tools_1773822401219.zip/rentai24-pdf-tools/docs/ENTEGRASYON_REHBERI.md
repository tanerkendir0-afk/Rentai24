# RentAI24 - PDF & Email Entegrasyon Rehberi

## Proje Yapısı

```
rentai24-pdf-tools/
├── fonts/                          ← Türkçe karakter desteği
│   ├── DejaVuSans.ttf
│   ├── DejaVuSans-Bold.ttf
│   ├── DejaVuSans-Oblique.ttf
│   └── DejaVuSans-BoldOblique.ttf
├── tools/
│   ├── pdf_generator.py            ← PDF oluşturucu (fatura, rapor)
│   └── agent_tool_registry.py      ← Tool yönetimi + agent ataması
├── services/
│   └── email_service.py            ← Email gönderme (HTML + attachment)
├── docs/
│   ├── ENTEGRASYON_REHBERI.md      ← Bu dosya
│   └── system_prompt_updates.py    ← Agent prompt güncellemeleri
└── requirements.txt
```

## 1. Kurulum

```bash
# 1. Dosyaları projeye kopyala
cp -r rentai24-pdf-tools/ /path/to/rentai24/

# 2. Bağımlılıkları kur
pip install -r rentai24-pdf-tools/requirements.txt

# 3. fonts/ dizininin yerinde olduğunu kontrol et
ls rentai24-pdf-tools/fonts/DejaVuSans.ttf
```

Font sistemi otomatik çalışır: önce proje içindeki `fonts/` dizinine bakar, bulamazsa sistem fontlarına (`/usr/share/fonts/truetype/dejavu/`) düşer. Replit'te fonts/ dizinini projeyle birlikte deploy etmen yeterli.

## 2. Environment Variables

```bash
# .env dosyasına ekle — birini seç:
EMAIL_PROVIDER=sendgrid   # veya: resend, smtp, auto

# SendGrid (önerilen)
SENDGRID_API_KEY=SG.xxxxxxxxxxxx
SENDGRID_FROM_EMAIL=noreply@rentai24.com

# Resend (alternatif)
RESEND_API_KEY=re_xxxxxxxxxxxx
RESEND_FROM_EMAIL=noreply@rentai24.com

# SMTP (fallback — Gmail için App Password kullan)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=app_password_here
```

## 3. White-Label Branding

Her müşteri kendi markasını tanımlar. `customer_settings` tablosuna `branding JSONB` kolonu ekle:

```sql
ALTER TABLE customer_settings
ADD COLUMN branding JSONB DEFAULT '{}';
```

Branding şeması:
```json
{
  "company_name": "ABC Demir Çelik A.Ş.",
  "logo_base64": "iVBORw0KGgo...",
  "theme": {
    "primary": "#1B4332",
    "accent": "#40916C",
    "light": "#D8F3DC",
    "text": "#1B1B1B"
  },
  "footer_text": "ABC Demir Çelik A.Ş. — Tüm hakları saklıdır.",
  "show_powered_by": false
}
```

PDF'te ve email'de RentAI24 adı görünmez. Müşteri `show_powered_by: true` derse küçük bir "Powered by RentAI24" eklenir.

## 4. Agent Engine Entegrasyonu

```python
from tools.agent_tool_registry import create_default_registry

# Uygulama başlangıcında
tool_registry = create_default_registry()

async def process_agent_message(agent_name: str, user_message: str, customer_id: str):
    # Müşteri branding'ini DB'den çek
    branding = get_customer_branding(customer_id)

    # Agent'ın tool'larını al
    tools = tool_registry.get_tools_for_agent(agent_name)

    # Claude API çağrısı
    response = await client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        system=get_system_prompt(agent_name),
        tools=tools,
        messages=[{"role": "user", "content": user_message}]
    )

    # Tool call loop
    while response.stop_reason == "tool_use":
        tool_block = next(b for b in response.content if b.type == "tool_use")

        result = tool_registry.execute_tool(
            tool_name=tool_block.name,
            tool_input=tool_block.input,
            customer_id=customer_id,
            branding=branding
        )

        response = await client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=get_system_prompt(agent_name),
            tools=tools,
            messages=[
                {"role": "user", "content": user_message},
                {"role": "assistant", "content": response.content},
                {"role": "user", "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_block.id,
                    "content": json.dumps(result, ensure_ascii=False)
                }]}
            ]
        )

    return next(b.text for b in response.content if b.type == "text")
```

## 5. System Prompt Güncelleme

```python
from docs.system_prompt_updates import (
    FINN_SYSTEM_PROMPT_ADDITION,
    UNIVERSAL_AGENT_PROMPT_ADDITION,
    REX_SALES_PROMPT_ADDITION,
    AVA_HR_PROMPT_ADDITION,
    DATABOT_ANALYTICS_PROMPT_ADDITION,
    SHOPBOT_ECOMMERCE_PROMPT_ADDITION,
)

def get_system_prompt(agent_name: str) -> str:
    base = load_base_prompt(agent_name)
    base += UNIVERSAL_AGENT_PROMPT_ADDITION

    additions = {
        "finn": FINN_SYSTEM_PROMPT_ADDITION,
        "rex": REX_SALES_PROMPT_ADDITION,
        "ava": AVA_HR_PROMPT_ADDITION,
        "databot": DATABOT_ANALYTICS_PROMPT_ADDITION,
        "shopbot": SHOPBOT_ECOMMERCE_PROMPT_ADDITION,
    }
    base += additions.get(agent_name, "")
    return base
```

## 6. Akış Diyagramı

```
Kullanıcı: "Fatura oluştur ve mail at"
    │
    ▼
┌─────────────────────┐
│ Agent Engine         │ ← customer_id ile branding çeker
│ (tool_registry)      │
└────────┬────────────┘
         │ Claude → tool_use: generate_pdf
         ▼
┌─────────────────────┐
│ PDF Generator        │ ← müşteri teması + DejaVu Sans font
│ (white-label)        │ → base64 PDF döner
└────────┬────────────┘
         │ Claude → tool_use: send_email (attachment: PDF)
         ▼
┌─────────────────────┐
│ Email Service        │ ← HTML body + PDF attachment
│ (SendGrid/Resend)    │ → müşterinin alıcısına gönderir
└────────┬────────────┘
         ▼
    ✅ Profesyonel fatura (müşteri markasıyla)
       PDF ek olarak email'de
```

## 7. Agent Tool Atamaları

| Agent    | generate_pdf | send_email | Kullanım Alanı           |
|----------|:---:|:---:|----------------------------------|
| Finn     | ✅  | ✅  | Fatura, mali rapor               |
| Rex      | ✅  | ✅  | Satış teklifi, pipeline raporu   |
| Ava      | ✅  | ✅  | İK sözleşme, performans raporu   |
| Maya     | ✅  | ✅  | Pazarlama analiz raporu          |
| Cal      | ❌  | ✅  | Takvim bildirimleri              |
| Harper   | ✅  | ✅  | İçerik raporu                    |
| DataBot  | ✅  | ✅  | Veri analiz raporu               |
| ShopBot  | ✅  | ✅  | Sipariş/fatura                   |

## 8. Hızlı Test

```python
from tools.pdf_generator import InvoicePDFGenerator

brand = {
    "company_name": "Test Firma A.Ş.",
    "theme": {"primary": "#B71C1C", "accent": "#E53935", "light": "#FFEBEE", "text": "#1B1B1B"},
    "footer_text": "Test Firma A.Ş.",
}

gen = InvoicePDFGenerator(branding=brand)
gen.generate_to_file({
    "invoice_no": "TEST-001",
    "date": "18.03.2026",
    "seller": {"name": "Test Firma A.Ş."},
    "buyer": {"name": "Müşteri Ltd. Şti."},
    "items": [{
        "description": "İnşaat Demiri",
        "quantity": 100,
        "unit": "ton",
        "unit_price": 29300,
        "vat_rate": 20,
        "withholding_rate": "9/10"
    }],
    "payment_terms": "30 gün",
    "currency": "₺"
}, "test.pdf")
```

## 9. Sorun Giderme

| Sorun | Çözüm |
|-------|-------|
| ■ kare karakterler | fonts/ dizinini kontrol et, DejaVu Sans yüklü mü? |
| Font bulunamadı hatası | `fonts/` dizinini proje root'una kopyala |
| PDF boş | `pip install reportlab` kontrol |
| Email gönderilmiyor | ENV değişkenlerini kontrol et |
| Markdown email body | System prompt'u güncelle (docs/system_prompt_updates.py) |
| Tevkifat yanlış | withholding_rate formatı: "9/10" (string) |
