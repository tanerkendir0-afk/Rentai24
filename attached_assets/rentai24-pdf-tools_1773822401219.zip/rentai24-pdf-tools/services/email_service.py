"""
RentAI24 - Universal Email Service with Attachment Support
============================================================
Tüm agentlar tarafından kullanılabilen email servisi.
PDF ve diğer dosyaları attachment olarak ekleme desteği.

Desteklenen servisler:
- SendGrid (birincil)
- Resend (alternatif)
- SMTP (fallback)
"""

import os
import json
import base64
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from typing import Optional


# ============================================================
# EMAIL TOOL TANIMI - Claude Function Calling
# ============================================================
EMAIL_TOOL_DEFINITION = {
    "name": "send_email",
    "description": (
        "E-posta gönderir. HTML formatında body, PDF veya diğer dosyaları "
        "attachment olarak ekleme desteği vardır. Fatura, rapor gibi PDF'leri "
        "generate_pdf tool'u ile oluşturup bu tool ile gönderebilirsin."
    ),
    "input_schema": {
        "type": "object",
        "required": ["to", "subject", "body"],
        "properties": {
            "to": {
                "type": "string",
                "description": "Alıcı email adresi"
            },
            "cc": {
                "type": "string",
                "description": "CC email adresi (opsiyonel)"
            },
            "subject": {
                "type": "string",
                "description": "E-posta konusu"
            },
            "body": {
                "type": "string",
                "description": "E-posta gövdesi (düz metin)"
            },
            "html_body": {
                "type": "string",
                "description": "HTML formatında e-posta gövdesi (opsiyonel, varsa body yerine kullanılır)"
            },
            "attachments": {
                "type": "array",
                "description": "Ekler listesi",
                "items": {
                    "type": "object",
                    "required": ["filename", "content_base64", "content_type"],
                    "properties": {
                        "filename": {
                            "type": "string",
                            "description": "Dosya adı (örn: fatura.pdf)"
                        },
                        "content_base64": {
                            "type": "string",
                            "description": "Base64 encoded dosya içeriği"
                        },
                        "content_type": {
                            "type": "string",
                            "description": "MIME tipi (örn: application/pdf)"
                        }
                    }
                }
            }
        }
    }
}


# ============================================================
# SENDGRID İLE EMAIL GÖNDERME
# ============================================================
def send_via_sendgrid(email_data: dict) -> dict:
    """
    SendGrid API kullanarak email gönderir.
    Requires: SENDGRID_API_KEY env variable
    """
    import httpx  # veya requests

    api_key = os.environ.get("SENDGRID_API_KEY")
    if not api_key:
        return {"success": False, "error": "SENDGRID_API_KEY tanımlı değil"}

    from_email = os.environ.get("SENDGRID_FROM_EMAIL", "noreply@rentai24.com")

    # SendGrid payload
    payload = {
        "personalizations": [{
            "to": [{"email": email_data["to"]}],
        }],
        "from": {"email": from_email, "name": "RentAI24"},
        "subject": email_data["subject"],
    }

    # CC
    if email_data.get("cc"):
        payload["personalizations"][0]["cc"] = [{"email": email_data["cc"]}]

    # Body - HTML tercih et
    if email_data.get("html_body"):
        payload["content"] = [{"type": "text/html", "value": email_data["html_body"]}]
    else:
        payload["content"] = [{"type": "text/plain", "value": email_data["body"]}]

    # Attachments
    if email_data.get("attachments"):
        payload["attachments"] = []
        for att in email_data["attachments"]:
            payload["attachments"].append({
                "content": att["content_base64"],
                "filename": att["filename"],
                "type": att.get("content_type", "application/octet-stream"),
                "disposition": "attachment"
            })

    try:
        import httpx
        response = httpx.post(
            "https://api.sendgrid.com/v3/mail/send",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json=payload,
            timeout=30
        )

        if response.status_code in (200, 201, 202):
            return {"success": True, "message": "Email başarıyla gönderildi (SendGrid)"}
        else:
            return {"success": False, "error": f"SendGrid hatası: {response.status_code} - {response.text}"}

    except Exception as e:
        return {"success": False, "error": f"SendGrid bağlantı hatası: {str(e)}"}


# ============================================================
# RESEND İLE EMAIL GÖNDERME
# ============================================================
def send_via_resend(email_data: dict) -> dict:
    """
    Resend API kullanarak email gönderir.
    Requires: RESEND_API_KEY env variable
    """
    api_key = os.environ.get("RESEND_API_KEY")
    if not api_key:
        return {"success": False, "error": "RESEND_API_KEY tanımlı değil"}

    from_email = os.environ.get("RESEND_FROM_EMAIL", "noreply@rentai24.com")

    payload = {
        "from": from_email,
        "to": [email_data["to"]],
        "subject": email_data["subject"],
    }

    if email_data.get("html_body"):
        payload["html"] = email_data["html_body"]
    else:
        payload["text"] = email_data["body"]

    if email_data.get("attachments"):
        payload["attachments"] = []
        for att in email_data["attachments"]:
            payload["attachments"].append({
                "filename": att["filename"],
                "content": att["content_base64"],
                "content_type": att.get("content_type", "application/octet-stream"),
            })

    try:
        import httpx
        response = httpx.post(
            "https://api.resend.com/emails",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json=payload,
            timeout=30
        )

        if response.status_code == 200:
            return {"success": True, "message": "Email başarıyla gönderildi (Resend)"}
        else:
            return {"success": False, "error": f"Resend hatası: {response.status_code} - {response.text}"}

    except Exception as e:
        return {"success": False, "error": f"Resend bağlantı hatası: {str(e)}"}


# ============================================================
# SMTP İLE EMAIL GÖNDERME (Fallback)
# ============================================================
def send_via_smtp(email_data: dict) -> dict:
    """
    Standart SMTP ile email gönderir.
    Gmail, Outlook veya özel SMTP sunucu destekler.
    """
    smtp_host = os.environ.get("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.environ.get("SMTP_PORT", "587"))
    smtp_user = os.environ.get("SMTP_USER", "")
    smtp_pass = os.environ.get("SMTP_PASS", "")  # Gmail: App Password kullan

    if not smtp_user or not smtp_pass:
        return {"success": False, "error": "SMTP credentials tanımlı değil"}

    try:
        msg = MIMEMultipart()
        msg['From'] = smtp_user
        msg['To'] = email_data["to"]
        msg['Subject'] = email_data["subject"]

        if email_data.get("cc"):
            msg['Cc'] = email_data["cc"]

        # Body
        if email_data.get("html_body"):
            msg.attach(MIMEText(email_data["html_body"], 'html', 'utf-8'))
        else:
            msg.attach(MIMEText(email_data["body"], 'plain', 'utf-8'))

        # Attachments
        if email_data.get("attachments"):
            for att in email_data["attachments"]:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(base64.b64decode(att["content_base64"]))
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename="{att["filename"]}"'
                )
                content_type = att.get("content_type", "application/octet-stream")
                if content_type:
                    maintype, subtype = content_type.split('/')
                    part.set_type(content_type)
                msg.attach(part)

        # Gönder
        server = smtplib.SMTP(smtp_host, smtp_port)
        server.starttls()
        server.login(smtp_user, smtp_pass)

        recipients = [email_data["to"]]
        if email_data.get("cc"):
            recipients.append(email_data["cc"])

        server.send_message(msg)
        server.quit()

        return {"success": True, "message": "Email başarıyla gönderildi (SMTP)"}

    except Exception as e:
        return {"success": False, "error": f"SMTP hatası: {str(e)}"}


# ============================================================
# ANA HANDLER - Agent engine'den çağrılır
# ============================================================
def handle_send_email(tool_input: dict) -> dict:
    """
    Agent tool call handler.
    Sırasıyla SendGrid > Resend > SMTP dener.
    """
    # Hangi provider aktif?
    provider = os.environ.get("EMAIL_PROVIDER", "auto")

    if provider == "sendgrid":
        return send_via_sendgrid(tool_input)
    elif provider == "resend":
        return send_via_resend(tool_input)
    elif provider == "smtp":
        return send_via_smtp(tool_input)
    else:
        # Auto: sırayla dene
        for sender in [send_via_sendgrid, send_via_resend, send_via_smtp]:
            result = sender(tool_input)
            if result["success"]:
                return result
        return {"success": False, "error": "Hiçbir email servisi yapılandırılmamış. SENDGRID_API_KEY, RESEND_API_KEY veya SMTP credentials tanımlayın."}


# ============================================================
# HTML EMAIL TEMPLATE
# ============================================================
def build_invoice_email_html(invoice_data: dict, branding: dict = None) -> str:
    """
    Profesyonel fatura email HTML'i — müşterinin markasıyla.
    """
    branding = branding or {}
    theme = branding.get("theme", {})
    primary_color = theme.get("primary", "#2C3E50")
    company_name = branding.get("company_name", "")
    footer_text = branding.get("footer_text", "")

    seller_name = invoice_data.get("seller", {}).get("name", "---")
    buyer_name = invoice_data.get("buyer", {}).get("name", "---")
    invoice_no = invoice_data.get("invoice_no", "---")
    date = invoice_data.get("date", "---")
    due_date = invoice_data.get("due_date", "---")

    # Toplam hesapla
    grand_total = "---"
    items = invoice_data.get("items", [])
    if items:
        from decimal import Decimal, ROUND_HALF_UP
        subtotal = sum(Decimal(str(i.get("quantity", 0))) * Decimal(str(i.get("unit_price", 0))) for i in items)
        total_vat = sum(
            (Decimal(str(i.get("quantity", 0))) * Decimal(str(i.get("unit_price", 0))) * Decimal(str(i.get("vat_rate", 0))) / 100)
            .quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            for i in items
        )
        total_wh = Decimal('0')
        for i in items:
            wh = i.get("withholding_rate", "")
            if wh:
                parts = str(wh).split("/")
                if len(parts) == 2:
                    line_vat = (Decimal(str(i.get("quantity", 0))) * Decimal(str(i.get("unit_price", 0))) * Decimal(str(i.get("vat_rate", 0))) / 100)
                    total_wh += line_vat * Decimal(parts[0]) / Decimal(parts[1])
        gt = subtotal + total_vat - total_wh
        int_part = int(gt)
        dec_part = str(gt.quantize(Decimal('0.01'))).split('.')[1]
        grand_total = f"{int_part:,}".replace(",", ".") + f",{dec_part} ₺"

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: {primary_color}; padding: 20px 30px; border-radius: 8px 8px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 20px;">Fatura - {invoice_no}</h1>
    </div>

    <div style="background: #f8f9fa; padding: 25px 30px; border: 1px solid #e9ecef; border-top: none;">
        <p style="margin-top: 0;">Sayın {buyer_name.split()[0] if buyer_name != '---' else ''},</p>

        <p>Aşağıda belirtilen faturanızı bilgilerinize sunarız.
        <strong>Detaylı faturayı ekte PDF olarak bulabilirsiniz.</strong></p>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            <tr style="background: #e9ecef;">
                <td style="padding: 10px 15px; font-weight: bold; width: 40%;">Satıcı</td>
                <td style="padding: 10px 15px;">{seller_name}</td>
            </tr>
            <tr>
                <td style="padding: 10px 15px; font-weight: bold;">Alıcı</td>
                <td style="padding: 10px 15px;">{buyer_name}</td>
            </tr>
            <tr style="background: #e9ecef;">
                <td style="padding: 10px 15px; font-weight: bold;">Fatura Tarihi</td>
                <td style="padding: 10px 15px;">{date}</td>
            </tr>
            <tr>
                <td style="padding: 10px 15px; font-weight: bold;">Vade Tarihi</td>
                <td style="padding: 10px 15px;">{due_date}</td>
            </tr>
            <tr style="background: {primary_color}; color: white;">
                <td style="padding: 12px 15px; font-weight: bold; font-size: 16px;">Genel Toplam</td>
                <td style="padding: 12px 15px; font-weight: bold; font-size: 16px;">{grand_total}</td>
            </tr>
        </table>

        <p style="color: #666; font-size: 13px;">
            {footer_text if footer_text else ''}
        </p>
    </div>

    <div style="background: {primary_color}; padding: 12px 30px; border-radius: 0 0 8px 8px; text-align: center;">
        <span style="color: rgba(255,255,255,0.7); font-size: 12px;">
            {company_name if company_name else seller_name}
        </span>
    </div>
</body>
</html>"""
