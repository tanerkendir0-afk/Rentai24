"""
RentAI24 - Model-Agnostic Tool Registry & LLM Service
=======================================================
Hem Claude (Anthropic) hem OpenAI (GPT) destekler.
Tool tanımları ortak formatta tutulur, çağrı anında provider formatına dönüştürülür.
"""

import json
import os
from typing import Dict, Any, Callable, List, Optional


# ============================================================
# ORTAK TOOL TANIMLARI (Provider-agnostic)
# ============================================================
TOOL_GENERATE_PDF = {
    "name": "generate_pdf",
    "description": (
        "Müşterinin kendi markasıyla PDF belgesi oluşturur (fatura, rapor, teklif). "
        "Türkçe karakter desteği var. PDF oluşturmadan 'ekte PDF var' gibi ifadeler KULLANMA. "
        "Önce bu tool'u çağır, sonra sonucu kullanıcıya bildir."
    ),
    "parameters": {
        "type": "object",
        "required": ["document_type", "data"],
        "properties": {
            "document_type": {
                "type": "string",
                "enum": ["invoice", "report", "proposal", "receipt"],
                "description": "Belge tipi: invoice=fatura, report=rapor, proposal=teklif, receipt=makbuz"
            },
            "data": {
                "type": "object",
                "description": (
                    "Belge verisi. Fatura için: invoice_no, date, due_date, "
                    "seller{name,address,tax_office,tax_no,phone,email}, "
                    "buyer{name,address,tax_office,tax_no}, "
                    "items[{description,quantity,unit,unit_price,vat_rate,withholding_rate}], "
                    "payment_terms, bank_info{bank_name,iban,account_holder}, notes, currency"
                )
            },
            "filename": {
                "type": "string",
                "description": "Dosya adı (örn: fatura_FTR-2026-001.pdf)"
            }
        }
    }
}

TOOL_SEND_EMAIL = {
    "name": "send_email",
    "description": (
        "E-posta gönderir. PDF veya diğer dosyaları attachment olarak ekleyebilir. "
        "generate_pdf ile oluşturulan PDF'in base64 içeriğini attachments alanına ekle. "
        "Email body'sini HTML olarak gönder, markdown KULLANMA."
    ),
    "parameters": {
        "type": "object",
        "required": ["to", "subject", "body"],
        "properties": {
            "to": {"type": "string", "description": "Alıcı email adresi"},
            "cc": {"type": "string", "description": "CC email adresi (opsiyonel)"},
            "subject": {"type": "string", "description": "E-posta konusu"},
            "body": {"type": "string", "description": "E-posta gövdesi (düz metin fallback)"},
            "html_body": {"type": "string", "description": "HTML formatında e-posta gövdesi"},
            "attachments": {
                "type": "array",
                "description": "Ek dosyalar",
                "items": {
                    "type": "object",
                    "required": ["filename", "content_base64", "content_type"],
                    "properties": {
                        "filename": {"type": "string", "description": "Dosya adı"},
                        "content_base64": {"type": "string", "description": "Base64 dosya içeriği"},
                        "content_type": {"type": "string", "description": "MIME tipi (örn: application/pdf)"}
                    }
                }
            }
        }
    }
}

ALL_TOOLS = [TOOL_GENERATE_PDF, TOOL_SEND_EMAIL]


# ============================================================
# PROVIDER FORMAT DÖNÜŞTÜRÜCÜLERİ
# ============================================================
def format_tools_for_provider(tools: list, provider: str) -> list:
    """
    Ortak tool tanımlarını provider-specific formata dönüştürür.
    provider: "anthropic" veya "openai"
    """
    if provider == "anthropic":
        return [
            {
                "name": t["name"],
                "description": t["description"],
                "input_schema": t["parameters"]
            }
            for t in tools
        ]
    elif provider == "openai":
        return [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t["description"],
                    "parameters": t["parameters"]
                }
            }
            for t in tools
        ]
    else:
        raise ValueError(f"Desteklenmeyen provider: {provider}")


# ============================================================
# TOOL EXECUTOR
# ============================================================
def execute_tool(tool_name: str, tool_input: dict, branding: dict = None) -> dict:
    """Tool'u çalıştır — provider'dan bağımsız."""
    from tools.pdf_generator import handle_generate_pdf
    from services.email_service import handle_send_email

    if tool_name == "generate_pdf":
        return handle_generate_pdf(tool_input, branding=branding)
    elif tool_name == "send_email":
        return handle_send_email(tool_input)
    else:
        return {"success": False, "error": f"Bilinmeyen tool: {tool_name}"}


# ============================================================
# AGENT CONFIG
# ============================================================
AGENT_CONFIGS = {
    "finn": {
        "provider": "anthropic",
        "model": "claude-sonnet-4-20250514",
        "tools": ["generate_pdf", "send_email"],
    },
    "rex": {
        "provider": "openai",
        "model": "gpt-4o",
        "tools": ["generate_pdf", "send_email"],
    },
    "ava": {
        "provider": "anthropic",
        "model": "claude-haiku-4-5-20251001",
        "tools": ["generate_pdf", "send_email"],
    },
    "maya": {
        "provider": "openai",
        "model": "gpt-4o-mini",
        "tools": ["generate_pdf", "send_email"],
    },
    "cal": {
        "provider": "anthropic",
        "model": "claude-haiku-4-5-20251001",
        "tools": ["send_email"],
    },
    "harper": {
        "provider": "openai",
        "model": "gpt-4o",
        "tools": ["generate_pdf", "send_email"],
    },
    "databot": {
        "provider": "anthropic",
        "model": "claude-sonnet-4-20250514",
        "tools": ["generate_pdf", "send_email"],
    },
    "shopbot": {
        "provider": "openai",
        "model": "gpt-4o-mini",
        "tools": ["generate_pdf", "send_email"],
    },
}


def get_agent_config(agent_name: str) -> dict:
    return AGENT_CONFIGS.get(agent_name, {
        "provider": "anthropic",
        "model": "claude-sonnet-4-20250514",
        "tools": ["generate_pdf", "send_email"]
    })


def get_tools_for_agent(agent_name: str) -> list:
    config = get_agent_config(agent_name)
    tool_names = config.get("tools", [])
    return [t for t in ALL_TOOLS if t["name"] in tool_names]


# ============================================================
# CLAUDE (Anthropic) — Tool Call Loop
# ============================================================
def process_with_claude(system_prompt: str, user_message: str,
                        tools: list, branding: dict = None,
                        model: str = "claude-sonnet-4-20250514") -> dict:
    """
    Claude API ile tool call loop.
    Returns: {"text": "...", "pdf": {...} or None, "email_sent": bool}
    """
    from anthropic import Anthropic
    client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

    formatted_tools = format_tools_for_provider(tools, "anthropic")
    messages = [{"role": "user", "content": user_message}]

    pdf_result = None
    email_sent = False

    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=system_prompt,
        tools=formatted_tools,
        messages=messages
    )

    while response.stop_reason == "tool_use":
        assistant_content = response.content
        tool_results = []

        for block in assistant_content:
            if block.type == "tool_use":
                result = execute_tool(block.name, block.input, branding=branding)

                # PDF sonucunu sakla
                if block.name == "generate_pdf" and result.get("success"):
                    pdf_result = {
                        "filename": result["filename"],
                        "base64": result["base64_pdf"]
                    }
                if block.name == "send_email" and result.get("success"):
                    email_sent = True

                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(result, ensure_ascii=False)
                })

        messages.append({"role": "assistant", "content": assistant_content})
        messages.append({"role": "user", "content": tool_results})

        response = client.messages.create(
            model=model,
            max_tokens=4096,
            system=system_prompt,
            tools=formatted_tools,
            messages=messages
        )

    text = "".join(block.text for block in response.content if hasattr(block, 'text'))
    return {"text": text, "pdf": pdf_result, "email_sent": email_sent}


# ============================================================
# OPENAI (GPT) — Tool Call Loop
# ============================================================
def process_with_openai(system_prompt: str, user_message: str,
                        tools: list, branding: dict = None,
                        model: str = "gpt-4o") -> dict:
    """
    OpenAI API ile tool call loop.
    Returns: {"text": "...", "pdf": {...} or None, "email_sent": bool}
    """
    from openai import OpenAI
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

    formatted_tools = format_tools_for_provider(tools, "openai")
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message}
    ]

    pdf_result = None
    email_sent = False

    response = client.chat.completions.create(
        model=model,
        messages=messages,
        tools=formatted_tools,
        tool_choice="auto"
    )

    message = response.choices[0].message

    while message.tool_calls:
        messages.append(message)

        for tool_call in message.tool_calls:
            func_name = tool_call.function.name
            # ÖNEMLİ: OpenAI arguments'ı STRING olarak döner, parse gerekli!
            func_args = json.loads(tool_call.function.arguments)

            result = execute_tool(func_name, func_args, branding=branding)

            if func_name == "generate_pdf" and result.get("success"):
                pdf_result = {
                    "filename": result["filename"],
                    "base64": result["base64_pdf"]
                }
            if func_name == "send_email" and result.get("success"):
                email_sent = True

            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": json.dumps(result, ensure_ascii=False)
            })

        response = client.chat.completions.create(
            model=model,
            messages=messages,
            tools=formatted_tools,
            tool_choice="auto"
        )
        message = response.choices[0].message

    return {"text": message.content or "", "pdf": pdf_result, "email_sent": email_sent}


# ============================================================
# ANA FONKSİYON — Provider'a göre yönlendir
# ============================================================
def process_agent_message(
    agent_name: str,
    user_message: str,
    branding: dict = None,
    provider_override: str = None,
    model_override: str = None
) -> dict:
    """
    Herhangi bir agent'ın mesajını işler.

    Args:
        agent_name: "finn", "rex", vb.
        user_message: Kullanıcının mesajı
        branding: Müşteri marka ayarları (DB'den çekilmiş)
        provider_override: Config'deki provider'ı override et
        model_override: Config'deki modeli override et

    Returns:
        {
            "text": "Agent'ın cevabı",
            "pdf": {"filename": "...", "base64": "..."} veya None,
            "email_sent": True/False
        }
    """
    config = get_agent_config(agent_name)
    provider = provider_override or config.get("provider", "anthropic")
    model = model_override or config.get("model")

    # System prompt
    from docs.system_prompt_updates import get_full_system_prompt
    system_prompt = get_full_system_prompt(agent_name)

    # Tool'ları belirle
    tools = get_tools_for_agent(agent_name)

    if provider == "anthropic":
        return process_with_claude(system_prompt, user_message, tools, branding, model)
    elif provider == "openai":
        return process_with_openai(system_prompt, user_message, tools, branding, model)
    else:
        raise ValueError(f"Desteklenmeyen provider: {provider}")


# ============================================================
# FATURA + EMAIL WORKFLOW (direkt çağrı — tool loop olmadan)
# ============================================================
def invoice_and_email_workflow(invoice_data: dict, to_email: str, branding: dict = None) -> dict:
    """
    Tool loop'a girmeden direkt fatura oluştur + email gönder.
    Backend'den programatik olarak çağrılabilir.
    """
    from tools.pdf_generator import handle_generate_pdf
    from services.email_service import handle_send_email, build_invoice_email_html

    # 1. PDF oluştur
    pdf_result = handle_generate_pdf(
        {"document_type": "invoice", "data": invoice_data,
         "filename": f"fatura_{invoice_data.get('invoice_no', 'DRAFT')}.pdf"},
        branding=branding
    )
    if not pdf_result.get("success"):
        return {"success": False, "error": f"PDF hatası: {pdf_result.get('error')}"}

    # 2. Email gönder
    html_body = build_invoice_email_html(invoice_data, branding=branding)
    buyer_name = invoice_data.get("buyer", {}).get("name", "")
    invoice_no = invoice_data.get("invoice_no", "")

    email_result = handle_send_email({
        "to": to_email,
        "subject": f"Fatura - {invoice_no}" if invoice_no else "Fatura",
        "body": f"Sayın {buyer_name}, faturanızı ekte bulabilirsiniz.",
        "html_body": html_body,
        "attachments": [{
            "filename": pdf_result["filename"],
            "content_base64": pdf_result["base64_pdf"],
            "content_type": "application/pdf"
        }]
    })

    return {
        "success": email_result.get("success", False),
        "pdf": {"filename": pdf_result["filename"], "base64": pdf_result["base64_pdf"]},
        "email_result": email_result.get("message") or email_result.get("error"),
    }
