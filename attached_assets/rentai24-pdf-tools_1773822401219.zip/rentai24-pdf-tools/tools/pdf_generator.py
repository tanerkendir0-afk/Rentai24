"""
RentAI24 - White-Label PDF Generation Tool
=============================================
Müşterinin kendi markasıyla PDF oluşturur.
DejaVu Sans font ile tam Türkçe karakter desteği:
ş Ş ı İ ğ Ğ ü Ü ö Ö ç Ç ₺
"""

import io
import os
import base64
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont


# ============================================================
# FONT KAYDI — Türkçe karakter desteği
# ============================================================
_fonts_registered = False

def _find_font_dir() -> str:
    """Font dizinini bul: önce proje içi, sonra sistem."""
    candidates = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts"),  # ../fonts/
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts"),               # relative
        os.path.join(os.getcwd(), "fonts"),                                                     # cwd/fonts/
        "/usr/share/fonts/truetype/dejavu",                                                     # Ubuntu/Debian
        "/usr/share/fonts/dejavu",                                                              # Fedora/RHEL
    ]
    for d in candidates:
        if os.path.exists(os.path.join(d, "DejaVuSans.ttf")):
            return d
    raise FileNotFoundError(
        "DejaVu Sans fontları bulunamadı! "
        "fonts/ dizinine DejaVuSans.ttf, DejaVuSans-Bold.ttf, "
        "DejaVuSans-Oblique.ttf, DejaVuSans-BoldOblique.ttf dosyalarını kopyalayın."
    )

def register_fonts():
    """DejaVu Sans fontlarını ReportLab'a kaydet. Bir kez çağrılır."""
    global _fonts_registered
    if _fonts_registered:
        return

    FONT_DIR = _find_font_dir()

    font_map = {
        "DejaVuSans":            f"{FONT_DIR}/DejaVuSans.ttf",
        "DejaVuSans-Bold":       f"{FONT_DIR}/DejaVuSans-Bold.ttf",
        "DejaVuSans-Oblique":    f"{FONT_DIR}/DejaVuSans-Oblique.ttf",
        "DejaVuSans-BoldOblique": f"{FONT_DIR}/DejaVuSans-BoldOblique.ttf",
    }

    for name, path in font_map.items():
        if os.path.exists(path):
            pdfmetrics.registerFont(TTFont(name, path))

    # Font ailesi olarak kaydet (bold/italic otomatik çözülsün)
    from reportlab.pdfbase.pdfmetrics import registerFontFamily
    registerFontFamily(
        'DejaVuSans',
        normal='DejaVuSans',
        bold='DejaVuSans-Bold',
        italic='DejaVuSans-Oblique',
        boldItalic='DejaVuSans-BoldOblique',
    )

    _fonts_registered = True


# Font isimlerini sabit olarak tanımla
FONT = "DejaVuSans"
FONT_BOLD = "DejaVuSans-Bold"
FONT_ITALIC = "DejaVuSans-Oblique"
FONT_BOLD_ITALIC = "DejaVuSans-BoldOblique"


# ============================================================
# VARSAYILAN TEMA
# ============================================================
DEFAULT_THEME = {
    "primary": "#2C3E50",
    "secondary": "#34495E",
    "accent": "#3498DB",
    "light": "#ECF0F1",
    "text": "#1B1B1B",
}


def get_customer_branding(customer_id: str) -> dict:
    """
    Müşterinin marka ayarlarını DB'den çeker.
    TODO: PostgreSQL implementasyonu
    """
    return {}


# ============================================================
# FATURA PDF (White-Label + Türkçe)
# ============================================================
class InvoicePDFGenerator:
    """
    Müşterinin kendi markasıyla profesyonel fatura PDF'i.
    Tam Türkçe karakter ve ₺ desteği.

    branding:
    {
        "company_name": "Firma Adı A.Ş.",
        "logo_path": "/path/to/logo.png",
        "logo_base64": "iVBORw0KGgo...",
        "theme": {"primary":"#1B4332","accent":"#40916C","light":"#D8F3DC","text":"#1B1B1B"},
        "footer_text": "Firma Adı A.Ş. — Tüm hakları saklıdır.",
        "show_powered_by": false
    }
    """

    def __init__(self, branding: dict = None):
        register_fonts()
        self.branding = branding or {}
        self.theme = self.branding.get("theme", DEFAULT_THEME)
        self.width, self.height = A4
        self._logo_path = self._resolve_logo()

    def _resolve_logo(self):
        if self.branding.get("logo_path") and os.path.exists(self.branding["logo_path"]):
            return self.branding["logo_path"]
        if self.branding.get("logo_base64"):
            path = "/tmp/_logo_temp.png"
            with open(path, "wb") as f:
                f.write(base64.b64decode(self.branding["logo_base64"]))
            return path
        return None

    def _format_currency(self, amount: float, currency: str = "₺") -> str:
        d = Decimal(str(amount)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        integer_part = int(d)
        decimal_part = str(d).split('.')[1] if '.' in str(d) else '00'
        int_str = f"{integer_part:,}".replace(",", ".")
        return f"{int_str},{decimal_part} {currency}"

    def _draw_header(self, c, doc):
        c.saveState()
        primary = HexColor(self.theme.get("primary", "#2C3E50"))
        accent = HexColor(self.theme.get("accent", "#3498DB"))

        # Üst banner
        c.setFillColor(primary)
        c.rect(0, self.height - 28*mm, self.width, 28*mm, fill=True, stroke=False)
        c.setFillColor(accent)
        c.rect(0, self.height - 29*mm, self.width, 1*mm, fill=True, stroke=False)

        # Logo
        if self._logo_path:
            try:
                c.drawImage(self._logo_path, 20*mm, self.height - 24*mm,
                           width=30*mm, height=18*mm, preserveAspectRatio=True, mask='auto')
            except Exception:
                pass

        # Firma adı
        company = self.branding.get("company_name", "")
        if company:
            c.setFillColor(white)
            c.setFont(FONT_BOLD, 12)
            x = 55*mm if self._logo_path else 20*mm
            c.drawString(x, self.height - 18*mm, company)

        c.restoreState()

    def _draw_footer(self, c, doc):
        c.saveState()
        primary = HexColor(self.theme.get("primary", "#2C3E50"))

        c.setFillColor(primary)
        c.rect(0, 0, self.width, 12*mm, fill=True, stroke=False)

        footer = self.branding.get("footer_text", "")
        if footer:
            c.setFillColor(white)
            c.setFont(FONT, 7)
            c.drawCentredString(self.width / 2, 5*mm, footer)

        if self.branding.get("show_powered_by", False):
            c.setFillColor(HexColor("#FFFFFF80"))
            c.setFont(FONT, 5)
            c.drawRightString(self.width - 20*mm, 2*mm, "Powered by RentAI24")

        c.restoreState()

    def generate(self, invoice_data: dict) -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4,
            rightMargin=20*mm, leftMargin=20*mm, topMargin=38*mm, bottomMargin=20*mm)

        story = []
        styles = getSampleStyleSheet()
        currency = invoice_data.get("currency", "₺")
        P = self.theme.get("primary", "#2C3E50")
        A = self.theme.get("accent", "#3498DB")
        L = self.theme.get("light", "#ECF0F1")
        T = self.theme.get("text", "#1B1B1B")

        # ---- Stiller (DejaVu Sans) ----
        title_s = ParagraphStyle('T', parent=styles['Heading1'], fontSize=22,
            textColor=HexColor(P), spaceAfter=6*mm, fontName=FONT_BOLD)
        section_s = ParagraphStyle('S', parent=styles['Heading2'], fontSize=11,
            textColor=HexColor(P), fontName=FONT_BOLD, spaceBefore=4*mm, spaceAfter=2*mm)
        normal_s = ParagraphStyle('N', parent=styles['Normal'], fontSize=9,
            textColor=HexColor(T), fontName=FONT, leading=13)
        bold_s = ParagraphStyle('B', parent=normal_s, fontName=FONT_BOLD)
        th_s = ParagraphStyle('TH', parent=normal_s, textColor=white, fontName=FONT_BOLD, fontSize=8)
        th_r = ParagraphStyle('THR', parent=th_s, alignment=TA_RIGHT)
        cell_r = ParagraphStyle('CR', parent=normal_s, alignment=TA_RIGHT, fontSize=9)
        cell_l = ParagraphStyle('CL', parent=normal_s, fontSize=9)

        # ---- BAŞLIK ----
        story.append(Paragraph("FATURA", title_s))

        meta = [
            ["Fatura No:", invoice_data.get("invoice_no", "---")],
            ["Tarih:", invoice_data.get("date", datetime.now().strftime("%d.%m.%Y"))],
            ["Vade:", invoice_data.get("due_date", "---")],
        ]
        mt = Table(meta, colWidths=[30*mm, 50*mm])
        mt.setStyle(TableStyle([
            ('FONTNAME', (0,0), (0,-1), FONT_BOLD),
            ('FONTNAME', (1,0), (1,-1), FONT),
            ('FONTSIZE', (0,0), (-1,-1), 9),
            ('TEXTCOLOR', (0,0), (0,-1), HexColor("#666666")),
            ('TEXTCOLOR', (1,0), (1,-1), HexColor(T)),
            ('TOPPADDING', (0,0), (-1,-1), 1),
            ('BOTTOMPADDING', (0,0), (-1,-1), 1),
            ('LEFTPADDING', (0,0), (-1,-1), 0),
        ]))
        story.append(mt)
        story.append(Spacer(1, 6*mm))

        # ---- SATICI / ALICI ----
        seller = invoice_data.get("seller", {})
        buyer = invoice_data.get("buyer", {})

        def _party(label, party):
            lines = [
                Paragraph(f"<b>{label}</b>", ParagraphStyle('PL', parent=normal_s,
                    fontSize=8, textColor=HexColor(A), fontName=FONT_BOLD, spaceAfter=2*mm)),
                Paragraph(f"<b>{party.get('name','---')}</b>", bold_s),
            ]
            for field, pfx in [('address',''), ('tax_office','VD: '), ('tax_no','VKN: '),
                                ('phone','Tel: '), ('email','E-posta: ')]:
                if party.get(field):
                    lines.append(Paragraph(f"{pfx}{party[field]}", normal_s))
            return lines

        pt = Table([[_party("SATICI", seller), _party("ALICI", buyer)]], colWidths=[85*mm, 85*mm])
        pt.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('LEFTPADDING', (0,0), (-1,-1), 0),
            ('RIGHTPADDING', (0,0), (-1,-1), 4*mm),
        ]))
        story.append(pt)
        story.append(Spacer(1, 6*mm))

        # ---- ÜRÜN TABLOSU ----
        story.append(HRFlowable(width="100%", thickness=0.5, color=HexColor(P), spaceAfter=2*mm))

        header_row = [
            Paragraph("<b>#</b>", th_s),
            Paragraph("<b>Ürün / Hizmet</b>", th_s),
            Paragraph("<b>Miktar</b>", th_r),
            Paragraph("<b>Birim Fiyat</b>", th_r),
            Paragraph("<b>KDV %</b>", th_r),
            Paragraph("<b>Tutar</b>", th_r),
        ]
        table_data = [header_row]

        subtotal = Decimal('0')
        total_vat = Decimal('0')
        total_wh = Decimal('0')

        for idx, item in enumerate(invoice_data.get("items", []), 1):
            qty = Decimal(str(item.get("quantity", 0)))
            up = Decimal(str(item.get("unit_price", 0)))
            vr = Decimal(str(item.get("vat_rate", 0)))
            lt = qty * up
            lv = (lt * vr / 100).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            subtotal += lt
            total_vat += lv

            wh_str = item.get("withholding_rate", "")
            if wh_str:
                parts = str(wh_str).split("/")
                if len(parts) == 2:
                    total_wh += (lv * Decimal(parts[0]) / Decimal(parts[1])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

            unit = item.get("unit", "adet")
            table_data.append([
                Paragraph(str(idx), cell_l),
                Paragraph(item.get("description", ""), cell_l),
                Paragraph(f"{qty:,.0f} {unit}".replace(",", "."), cell_r),
                Paragraph(self._format_currency(float(up), currency), cell_r),
                Paragraph(f"%{vr:.0f}", cell_r),
                Paragraph(self._format_currency(float(lt), currency), cell_r),
            ])

        cw = [10*mm, 55*mm, 25*mm, 30*mm, 18*mm, 32*mm]
        it = Table(table_data, colWidths=cw, repeatRows=1)
        it.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), HexColor(P)),
            ('TEXTCOLOR', (0,0), (-1,0), white),
            *[('BACKGROUND', (0,i), (-1,i), HexColor(L)) for i in range(2, len(table_data), 2)],
            ('LINEBELOW', (0,0), (-1,0), 1, HexColor(P)),
            ('LINEBELOW', (0,-1), (-1,-1), 0.5, HexColor("#CCCCCC")),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('TOPPADDING', (0,0), (-1,-1), 3*mm),
            ('BOTTOMPADDING', (0,0), (-1,-1), 3*mm),
            ('LEFTPADDING', (0,0), (-1,-1), 2*mm),
            ('RIGHTPADDING', (0,0), (-1,-1), 2*mm),
        ]))
        story.append(it)
        story.append(Spacer(1, 4*mm))

        # ---- TOPLAM ----
        grand = subtotal + total_vat - total_wh
        sum_lbl = ParagraphStyle('SL', parent=normal_s, alignment=TA_RIGHT, fontSize=9, textColor=HexColor("#666666"))
        sum_val = ParagraphStyle('SV', parent=normal_s, alignment=TA_RIGHT, fontSize=9)
        sum_tot = ParagraphStyle('ST', parent=bold_s, alignment=TA_RIGHT, fontSize=11, textColor=HexColor(P))

        rows = [
            [Paragraph("Ara Toplam:", sum_lbl), Paragraph(self._format_currency(float(subtotal), currency), sum_val)],
            [Paragraph("KDV Toplam:", sum_lbl), Paragraph(self._format_currency(float(total_vat), currency), sum_val)],
        ]
        if total_wh > 0:
            rows.append([Paragraph("Tevkifat Kesintisi:", sum_lbl),
                         Paragraph(f"-{self._format_currency(float(total_wh), currency)}", sum_val)])
        rows.append([Paragraph("GENEL TOPLAM:", sum_tot),
                     Paragraph(self._format_currency(float(grand), currency), sum_tot)])

        st = Table(rows, colWidths=[40*mm, 45*mm], hAlign='RIGHT')
        st.setStyle(TableStyle([
            ('LINEABOVE', (0,-1), (-1,-1), 1, HexColor(P)),
            ('TOPPADDING', (0,0), (-1,-1), 2*mm),
            ('BOTTOMPADDING', (0,0), (-1,-1), 2*mm),
            ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ]))
        story.append(st)
        story.append(Spacer(1, 6*mm))

        # ---- BANKA BİLGİLERİ ----
        bank = invoice_data.get("bank_info", {})
        if bank:
            story.append(Paragraph("BANKA BİLGİLERİ", section_s))
            if bank.get("bank_name"):
                story.append(Paragraph(f"Banka: {bank['bank_name']}", normal_s))
            if bank.get("iban"):
                story.append(Paragraph(f"IBAN: {bank['iban']}", bold_s))
            if bank.get("account_holder"):
                story.append(Paragraph(f"Hesap Sahibi: {bank['account_holder']}", normal_s))
            story.append(Spacer(1, 4*mm))

        # ---- ÖDEME / NOTLAR ----
        if invoice_data.get("payment_terms"):
            story.append(Paragraph("ÖDEME KOŞULLARI", section_s))
            story.append(Paragraph(f"Vade: {invoice_data['payment_terms']}", normal_s))
            story.append(Spacer(1, 4*mm))

        if invoice_data.get("notes"):
            story.append(Paragraph("NOTLAR", section_s))
            story.append(Paragraph(invoice_data["notes"], normal_s))

        # Build
        doc.build(story, onFirstPage=self._draw_header, onLaterPages=self._draw_header)
        result = buffer.getvalue()
        buffer.close()
        return result

    def generate_to_file(self, invoice_data: dict, output_path: str) -> str:
        with open(output_path, 'wb') as f:
            f.write(self.generate(invoice_data))
        return output_path

    def generate_to_base64(self, invoice_data: dict) -> str:
        return base64.b64encode(self.generate(invoice_data)).decode('utf-8')


# ============================================================
# RAPOR PDF (White-Label + Türkçe)
# ============================================================
class ReportPDFGenerator:
    def __init__(self, branding: dict = None):
        register_fonts()
        self.branding = branding or {}
        self.theme = self.branding.get("theme", DEFAULT_THEME)

    def generate(self, report_data: dict) -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4,
            rightMargin=20*mm, leftMargin=20*mm, topMargin=25*mm, bottomMargin=20*mm)
        styles = getSampleStyleSheet()
        story = []
        P = self.theme.get("primary", "#2C3E50")
        A = self.theme.get("accent", "#3498DB")
        L = self.theme.get("light", "#ECF0F1")

        story.append(Paragraph(report_data.get("title", "Rapor"),
            ParagraphStyle('T', parent=styles['Title'], fontSize=20,
                textColor=HexColor(P), fontName=FONT_BOLD, spaceAfter=2*mm)))

        if report_data.get("subtitle"):
            story.append(Paragraph(report_data["subtitle"],
                ParagraphStyle('S', parent=styles['Normal'], fontSize=11,
                    textColor=HexColor("#888"), fontName=FONT)))
        if report_data.get("author"):
            story.append(Paragraph(f"Hazırlayan: {report_data['author']}",
                ParagraphStyle('A', parent=styles['Normal'], fontSize=9,
                    textColor=HexColor(A), fontName=FONT_ITALIC)))

        story.append(Spacer(1, 8*mm))
        story.append(HRFlowable(width="100%", thickness=1, color=HexColor(P)))
        story.append(Spacer(1, 6*mm))

        normal = ParagraphStyle('N', parent=styles['Normal'], fontSize=10, leading=14, fontName=FONT)
        heading = ParagraphStyle('H', parent=styles['Heading2'], fontSize=13,
            textColor=HexColor(P), fontName=FONT_BOLD, spaceBefore=6*mm, spaceAfter=3*mm)

        for sec in report_data.get("sections", []):
            if sec.get("heading"):
                story.append(Paragraph(sec["heading"], heading))
            if sec.get("content"):
                story.append(Paragraph(sec["content"], normal))
                story.append(Spacer(1, 3*mm))
            if sec.get("table"):
                all_rows = [sec["table"].get("headers", [])] + sec["table"].get("rows", [])
                t = Table(all_rows)
                t.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,0), HexColor(P)),
                    ('TEXTCOLOR', (0,0), (-1,0), white),
                    ('FONTNAME', (0,0), (-1,0), FONT_BOLD),
                    ('FONTNAME', (0,1), (-1,-1), FONT),
                    ('FONTSIZE', (0,0), (-1,-1), 9),
                    ('GRID', (0,0), (-1,-1), 0.5, HexColor("#CCC")),
                    ('TOPPADDING', (0,0), (-1,-1), 2*mm),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 2*mm),
                    *[('BACKGROUND', (0,i), (-1,i), HexColor(L)) for i in range(2, len(all_rows), 2)],
                ]))
                story.append(t)
                story.append(Spacer(1, 4*mm))

        doc.build(story)
        result = buffer.getvalue()
        buffer.close()
        return result

    def generate_to_file(self, report_data: dict, output_path: str) -> str:
        with open(output_path, 'wb') as f:
            f.write(self.generate(report_data))
        return output_path

    def generate_to_base64(self, report_data: dict) -> str:
        return base64.b64encode(self.generate(report_data)).decode('utf-8')


# ============================================================
# TOOL TANIMI & HANDLER
# ============================================================
TOOL_DEFINITIONS = [{
    "name": "generate_pdf",
    "description": "Müşterinin kendi markasıyla PDF belgesi oluşturur (fatura, rapor, teklif). Türkçe karakter desteği.",
    "input_schema": {
        "type": "object",
        "required": ["document_type", "data"],
        "properties": {
            "document_type": {"type": "string", "enum": ["invoice", "report", "proposal", "receipt"]},
            "data": {"type": "object", "description": "Belge verisi"},
            "filename": {"type": "string", "description": "Dosya adı"}
        }
    }
}]


def handle_generate_pdf(tool_input: dict, customer_id: str = None, branding: dict = None) -> dict:
    doc_type = tool_input.get("document_type", "invoice")
    data = tool_input.get("data", {})
    filename = tool_input.get("filename", f"{doc_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")

    if branding is None and customer_id:
        branding = get_customer_branding(customer_id)

    try:
        if doc_type == "invoice":
            gen = InvoicePDFGenerator(branding=branding)
        elif doc_type in ("report", "proposal"):
            gen = ReportPDFGenerator(branding=branding)
        else:
            return {"success": False, "error": f"Desteklenmeyen tip: {doc_type}"}

        pdf_b64 = gen.generate_to_base64(data)
        fpath = f"/tmp/{filename}"
        gen.generate_to_file(data, fpath)

        return {
            "success": True,
            "filename": filename,
            "base64_pdf": pdf_b64,
            "file_path": fpath,
            "message": f"PDF oluşturuldu: {filename}"
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============================================================
# TEST
# ============================================================
if __name__ == "__main__":
    # Kendirliler testi — Türkçe karakterler
    brand = {
        "company_name": "Kendirliler Haddecilik A.Ş.",
        "theme": {"primary": "#1B4332", "accent": "#40916C", "light": "#D8F3DC", "text": "#1B1B1B"},
        "footer_text": "Kendirliler Haddecilik A.Ş. — Tüm hakları saklıdır.",
    }

    gen = InvoicePDFGenerator(branding=brand)
    gen.generate_to_file({
        "invoice_no": "FTR-2026-0042",
        "date": "18.03.2026",
        "due_date": "17.04.2026",
        "seller": {
            "name": "Kendirliler Haddecilik A.Ş.",
            "address": "Organize Sanayi Bölgesi, Kayseri",
            "tax_office": "Kayseri Vergi Dairesi",
            "tax_no": "1234567890",
            "phone": "+90 352 XXX XX XX",
            "email": "info@kendirliler.com"
        },
        "buyer": {
            "name": "Yunus Kendir Demir Çelik A.Ş.",
            "address": "Sanayi Mahallesi, Kayseri",
            "tax_office": "Kayseri Vergi Dairesi",
            "tax_no": "0987654321"
        },
        "items": [
            {
                "description": "İnşaat Demiri",
                "quantity": 500,
                "unit": "ton",
                "unit_price": 29300.00,
                "vat_rate": 20,
                "withholding_rate": "9/10"
            }
        ],
        "payment_terms": "30 gün vadeli",
        "notes": "Teslimat fabrika çıkışı (Ex-Works) olarak yapılacaktır.",
        "currency": "₺"
    }, "/tmp/test_turkce.pdf")

    size = os.path.getsize("/tmp/test_turkce.pdf")
    print(f"Türkçe fatura: /tmp/test_turkce.pdf ({size} bytes)")
    print("Kontrol: Ş, İ, ı, ğ, ç, ö, ü, ₺ karakterleri doğru görünmeli.")
